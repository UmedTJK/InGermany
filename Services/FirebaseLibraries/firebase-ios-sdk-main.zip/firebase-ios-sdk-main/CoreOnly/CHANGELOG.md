Please go to https://firebase.google.com/support/release-notes/ios
to view the Firebase iOS release notes.

You can find information about prior changes to the Firebase pod and Firebase
Database [here](https://www.firebase.com/docs/ios/changelog.html).
