# Firebase AI SDK Quickstart

 Try out the
 [Firebase AI SDK Quickstart](https://github.com/firebase/quickstart-ios/tree/main/firebaseai)
 in the `quickstart-ios` repository to get started.
